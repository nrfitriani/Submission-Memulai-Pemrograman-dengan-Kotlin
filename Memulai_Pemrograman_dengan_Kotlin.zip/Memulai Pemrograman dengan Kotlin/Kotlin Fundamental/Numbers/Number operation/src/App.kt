fun main() {
    val numberOne = 1
    val numberTwo = 2

    println(numberOne + numberTwo)

    println(numberOne / numberTwo)

    println(5 + 4 * 4)

    println((5 + 4) * 4)

}