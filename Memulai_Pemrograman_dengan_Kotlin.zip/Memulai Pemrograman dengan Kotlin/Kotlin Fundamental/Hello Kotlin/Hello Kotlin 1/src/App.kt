// main function
fun main() {
    println("Hello kotlin!")
}