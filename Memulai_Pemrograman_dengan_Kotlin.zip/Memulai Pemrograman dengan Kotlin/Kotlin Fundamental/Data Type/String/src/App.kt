// main function
fun main() {
    val text  = "Kotlin"
    val firstChar = text[1]

    print("First character of $text is $firstChar")
}