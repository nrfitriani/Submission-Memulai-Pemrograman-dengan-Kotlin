// type your solution here
fun main() {
    val statement = "Kotlin is \"Awesome!\""
    println(statement)
}