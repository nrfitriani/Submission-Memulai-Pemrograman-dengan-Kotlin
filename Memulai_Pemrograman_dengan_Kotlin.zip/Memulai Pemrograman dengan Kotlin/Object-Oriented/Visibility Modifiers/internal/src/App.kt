internal class Animal(val name: String)

fun main() {
    println("internal visibility modifier")
}

