fun main() {

    print("Kotlin,")
    println()
    print("is Awesome!")
}